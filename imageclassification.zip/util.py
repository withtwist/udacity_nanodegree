import json
from torchvision import transforms
from torch.utils.data import dataloader
from torchvision import datasets, models, transforms
from torch import nn
import torch.nn.functional as F
import torchvision.transforms.functional as F_vision
from collections import OrderedDict
from sklearn.preprocessing import scale

def get_categories():
    with open('cat_to_name.json', 'r') as f:
        cat_to_name = json.load(f)
    return cat_to_name

def get_train_datautils(path):
    train_dir = path + "/train"
    train_transforms = transforms.Compose([
        transforms.RandomRotation(13),
        transforms.RandomResizedCrop(224),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])
    train_dataset = datasets.ImageFolder(train_dir, transform=train_transforms)    
    trainloader = dataloader.DataLoader(train_dataset, batch_size=32, shuffle=True)
    return train_dataset, trainloader

    
def get_test_datautils(path):
    test_dir = path + "/test"
    test_transforms = transforms.Compose([
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])
    test_dataset = datasets.ImageFolder(test_dir, transform=test_transforms)
    testloader = dataloader.DataLoader(test_dataset, batch_size=32, shuffle=True)
    return test_dataset, testloader

def get_valid_datautils(path):
    valid_dir = path + "/test"
    test_transforms = transforms.Compose([
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])
    valid_dataset = datasets.ImageFolder(valid_dir, transform=test_transforms)
    validloader = dataloader.DataLoader(valid_dataset, batch_size=32, shuffle=True)
    return valid_dataset, validloader
