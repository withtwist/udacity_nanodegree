import model
import util
import argparse
import torch


def main(parser):
    image_path = parser.image_path
    checkpoint = parser.checkpoint
    cat_to_name = parser.cat_to_name
    topk = int(parser.topk) if parser.topk else 5
    gpu = parser.gpu
    
    if gpu and torch.cuda.is_available():
        device = torch.device("cuda")
    else:
        device = torch.device("cpu")  
    loaded_model, optimizer = model.load_checkpoint(checkpoint, device)
    res = model.predict(image_path, loaded_model, device, cat_to_name, topk)
    for c, p in zip(*res):
        print("Class: {} | Confidence: {:f}".format(p, c))
        
if __name__ == "__main__":
    
    parser = argparse.ArgumentParser()
    parser.add_argument("image_path")
    parser.add_argument("checkpoint")
    parser.add_argument("--topk")
    parser.add_argument("--cat_to_name")
    parser.add_argument("--gpu", action="store_true")
    parser = parser.parse_args()
    main(parser)
    