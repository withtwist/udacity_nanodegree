from torchvision import models
import torch
from torch import nn
import json
import util
from torch import nn
import torch.nn.functional as F
from collections import OrderedDict
from PIL import Image
import numpy as np

def build_model(dropout_prob, arch, n_hidden, device):
    cat_to_name = util.get_categories()
    model_arch = getattr(models, arch)
    model = model_arch(pretrained=True)
    model.dropout_prob = dropout_prob
    model.n_hidden = n_hidden
    model.epochs = 0
    model.architecture = arch
    classifier = nn.Sequential(OrderedDict([
        ("fc1", nn.Linear(25088, n_hidden)),
        ("relu", nn.ReLU()),
        ("dropout1", nn.Dropout(dropout_prob)),
        ("fc2", nn.Linear(n_hidden, len(cat_to_name))),
        ("log_softmax", nn.LogSoftmax(dim=1))
    ]))
    for param in model.parameters():
        param.requires_grad = False
    
    
    if model.classifier:
        model.classifier = classifier
    elif model.fc:
        model.fc = classifier
        
    model.to(device)
    return model



def train_model(model, epochs, trainloader, validloader, criterion, optimizer, device):
    train_losses = []
    valid_losses = []
    for e in range(epochs):

        running_loss = 0
        for inputs, labels in trainloader:

            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad()

            outs = model(inputs)
            loss = criterion(outs, labels)

            loss.backward()
            optimizer.step()

            running_loss += loss.item()
        else:
            with torch.no_grad():
                valid_loss = 0
                accuracy = 0 
                for v_inputs, v_labels in validloader:
                    v_inputs, v_labels = v_inputs.to(device), v_labels.to(device)
                    v_outs = model(v_inputs)
                    valid_loss += criterion(v_outs, v_labels)

                    v_probs = torch.exp(v_outs)
                    top_p, top_class = v_probs.topk(1, dim=1)
                    equals = top_class == v_labels.view(*top_class.shape)

                    accuracy += torch.mean(equals.type(torch.FloatTensor)).item()

            print("Epoch {}/{}".format(e+1, epochs),
                "Model total epochs: {}".format(model.epochs),
                "Training loss: {}".format(running_loss/len(trainloader)),
                "Validation loss: {}".format(valid_loss/len(validloader)),
                "Accuracy: {}".format(accuracy/len(validloader)))
            model.epochs += 1
            train_losses.append(running_loss/len(trainloader))
            valid_losses.append(valid_loss/len(validloader))
                
def test_model(testloader, device, model, criterion):
    test_loss = 0
    test_acc = 0
    with torch.no_grad():
        for images, labels in testloader:
            images, labels = images.to(device), labels.to(device)
            test_out = model(images)
            test_loss += criterion(test_out, labels)

            t_probs = torch.exp(test_out)
            top_p, top_class = t_probs.topk(1, dim=1)
            equals = top_class == labels.view(*top_class.shape)
            print(equals)
            test_acc += torch.mean(equals.type(torch.FloatTensor)).item()

    print("Test loss: {}".format(test_loss/len(testloader)),
         "Test accuracy: {}".format(test_acc/len(testloader)))
    return test_loss, test_acc

def save_checkpoint(train_dataset, model, optimizer, cat_to_name, dropout_prob, lr, arch, n_hidden, filename):
    checkpoint = {
        "input_size": 244,
        "output_size": len(cat_to_name),
        "class_to_idx": train_dataset.class_to_idx,
        "model_state_dict": model.state_dict(),
        "epochs": model.epochs,
        "optimizer_state_dict": optimizer.state_dict(),
        "dropout_prob": model.dropout_prob,
        "lr": lr,
        "architecture": arch,
        "n_hidden": n_hidden
    }
    torch.save(checkpoint, filename)
    
def load_checkpoint(filename, dev):
    checkpoint = torch.load(filename, map_location=str(dev))
    model2 = build_model(checkpoint["dropout_prob"], checkpoint["architecture"], checkpoint["n_hidden"], dev)
    model2.load_state_dict(checkpoint["model_state_dict"])
    if model2.classifier:        
        optimizer = torch.optim.Adam(model2.classifier.parameters(), checkpoint["lr"])
    elif model2.fc:
        optimizer = torch.optim.Adam(model2.fc.parameters(), checkpoint["lr"])
    optimizer.load_state_dict(checkpoint["optimizer_state_dict"])    
    model2.epochs = checkpoint["epochs"]
    model2.class_to_idx = checkpoint["class_to_idx"]
    model2.lr = checkpoint["lr"]
    model2.dropout_prob = checkpoint["dropout_prob"]
    model2.n_hidden = checkpoint["n_hidden"]
    model2.architecture = checkpoint["architecture"]
    return model2, optimizer

def process_image(image):
    ''' Scales, crops, and normalizes a PIL image for a PyTorch model,
        returns an Numpy array
    '''
    image.thumbnail((512, 256), Image.ANTIALIAS)
    nwidth, nheight = 224, 224
    width, height =  image.size
    left = (width - nwidth)//2.
    top = (height - nheight)//2.
    right = (width + nwidth)//2.
    bottom = (height + nheight)//2.
    
    image = image.crop((left, top, right, bottom))
    
    np_image = np.array(image, dtype="float")
    
    np_image /= 255.0
    np_image = (np_image - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
    
    np_image = np_image.transpose(2,0,1)
    return np_image

    
def predict(image_path, model, device, cat_to_name, topk=5):
    ''' Predict the class (or classes) of an image using a trained deep learning model.
    '''
    with torch.no_grad():
        image = Image.open(image_path)
        image = process_image(image)
        inp = torch.from_numpy(image).unsqueeze(0).float()
        inp = inp.to(device)
        model_output = model(inp)
        probs = torch.exp(model_output)
        top_p, top_class = probs.topk(topk, dim=1)
        class_to_idx = model.class_to_idx
        idx_to_class = {y:x for x, y in class_to_idx.items()}
        top_ps = top_p.tolist()[0]
        top_classes = [idx_to_class[x] for x in top_class.tolist()[0]]
        if cat_to_name:
            with open(cat_to_name, 'r') as f:
                mapping = json.load(f)
            top_classes = [mapping[x] for x in top_classes]
        return top_ps, top_classes