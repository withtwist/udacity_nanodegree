import argparse
import util
import model
import torch

def main(parser):
    data_dir = parser.data_dir
    save_checkpoint = parser.save_checkpoint
    arch = parser.arch if parser.arch else "vgg11"
    epochs = int(parser.epochs) if parser.epochs else 10
    gpu = parser.gpu
    hidden_units = int(parser.hidden_units) if parser.hidden_units else 512
    learning_rate = float(parser.learning_rate) if parser.learning_rate else 0.001
    dropout_prob = parser.dropout_prob if parser.dropout_prob else 0.1
    if gpu and torch.cuda.is_available():
        device = torch.device("cuda:0")
    else:
        device = torch.device("cpu")  
    new_model = model.build_model(dropout_prob, arch, hidden_units, device)
    train_dataset, trainloader = util.get_train_datautils(data_dir)
    valid_dataset, validloader = util.get_valid_datautils(data_dir)
    criterion = torch.nn.NLLLoss()
    optimizer = torch.optim.Adam(new_model.classifier.parameters(), lr = learning_rate)
    model.train_model(new_model, epochs, trainloader, validloader, criterion, optimizer, device)
    if save_checkpoint:
        cat_to_name = util.get_categories()
        model.save_checkpoint(train_dataset, new_model, optimizer, cat_to_name, dropout_prob, learning_rate, arch, hidden_units, save_checkpoint)






if __name__ == "__main__":
    
    parser = argparse.ArgumentParser()
    parser.add_argument("data_dir")
    parser.add_argument("--save_checkpoint", dest="save_checkpoint")
    parser.add_argument("--arch")
    parser.add_argument("--epochs")
    parser.add_argument("--hidden_units")
    parser.add_argument("--learning_rate")
    parser.add_argument("--dropout_prob")
    parser.add_argument("--gpu", action="store_true")
    parser = parser.parse_args()
    main(parser)
    